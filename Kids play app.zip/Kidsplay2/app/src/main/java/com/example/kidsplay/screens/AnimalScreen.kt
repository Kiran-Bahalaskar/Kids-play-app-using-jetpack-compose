package com.example.kidsplay.screens

import android.media.MediaPlayer
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.kidsplay.R

@Composable
fun animalScreen(navController: NavController) {

    val mContext = LocalContext.current

    val cat = MediaPlayer.create(mContext, R.raw.cat)
    val dog = MediaPlayer.create(mContext, R.raw.dog)
    val horse = MediaPlayer.create(mContext, R.raw.horse)
    val buffalo = MediaPlayer.create(mContext, R.raw.buffalo)
    val cock = MediaPlayer.create(mContext, R.raw.cock)
    val goat = MediaPlayer.create(mContext, R.raw.goat)

    Column(
        modifier = Modifier.padding(10.dp)
    ) {

        Row(modifier = Modifier.weight(1f)) {

            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { cat.start() }
            ) {

                Box(modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()) {

                    Image(
                        painter = painterResource(id = R.drawable.cat),
                        contentDescription = "",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                }

            }

            Spacer(modifier = Modifier.width(10.dp))

            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { dog.start() }
            ) {

                Box(modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()) {

                    Image(
                        painter = painterResource(id = R.drawable.dog),
                        contentDescription = "",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                }

            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.weight(1f)) {

            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { horse.start() }
            ) {

                Box(modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()) {

                    Image(
                        painter = painterResource(id = R.drawable.horse),
                        contentDescription = "",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                }

            }

            Spacer(modifier = Modifier.width(10.dp))

            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { buffalo.start() }
            ) {

                Box(modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()) {

                    Image(
                        painter = painterResource(id = R.drawable.buffalo),
                        contentDescription = "",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                }

            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(modifier = Modifier.weight(1f)) {

            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { cock.start() }
            ) {

                Box(modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()) {

                    Image(
                        painter = painterResource(id = R.drawable.cock),
                        contentDescription = "",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                }

            }

            Spacer(modifier = Modifier.width(10.dp))

            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { goat.start() }
            ) {

                Box(modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()) {

                    Image(
                        painter = painterResource(id = R.drawable.goat),
                        contentDescription = "",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )

                }

            }
        }

    }

}