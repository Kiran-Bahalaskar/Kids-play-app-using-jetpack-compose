package com.example.kidsplay

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.kidsplay.screens.alphabetScreen
import com.example.kidsplay.screens.animalScreen
import com.example.kidsplay.screens.colorScreen
import com.example.kidsplay.screens.homeScreen
import com.example.kidsplay.screens.numberScreen
import com.example.kidsplay.screens.splashScreen
import com.example.kidsplay.ui.theme.KidsPlayTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            App()
        }
    }
}

@Composable
fun App() {
    val navController = rememberNavController()
    NavHost(navController = navController, startDestination = "splash_screen") {
        composable("splash_screen") {
            splashScreen(navController = navController)
        }

        composable("home_screen") {
            homeScreen(navController = navController)
        }

        composable("animal_screen") {
            animalScreen(navController = navController)
        }

        composable("number_screen") {
            numberScreen(navController = navController)
        }

        composable("alphabet_screen") {
            alphabetScreen(navController = navController)
        }

        composable("colors_screen") {
            colorScreen(navController = navController)
        }
    }
}