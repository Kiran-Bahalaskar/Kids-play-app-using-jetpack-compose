package com.example.kidsplay.screens

import android.media.MediaPlayer
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.colorResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.kidsplay.R

@Composable
fun alphabetScreen(navController: NavController) {


    val mContext = LocalContext.current

    val a = MediaPlayer.create(mContext, R.raw.a)
    val b = MediaPlayer.create(mContext, R.raw.b)
    val c = MediaPlayer.create(mContext, R.raw.c)
    val d = MediaPlayer.create(mContext, R.raw.d)
    val e = MediaPlayer.create(mContext, R.raw.e)
    val f = MediaPlayer.create(mContext, R.raw.f)
    val g = MediaPlayer.create(mContext, R.raw.g)
    val h = MediaPlayer.create(mContext, R.raw.h)
    val i = MediaPlayer.create(mContext, R.raw.i)
    val j = MediaPlayer.create(mContext, R.raw.j)

    val k = MediaPlayer.create(mContext, R.raw.k)
    val l = MediaPlayer.create(mContext, R.raw.l)
    val m = MediaPlayer.create(mContext, R.raw.m)
    val n = MediaPlayer.create(mContext, R.raw.n)
    val o = MediaPlayer.create(mContext, R.raw.o)
    val p = MediaPlayer.create(mContext, R.raw.p)
    val q = MediaPlayer.create(mContext, R.raw.q)
    val r = MediaPlayer.create(mContext, R.raw.r)
    val s = MediaPlayer.create(mContext, R.raw.s)
    val t = MediaPlayer.create(mContext, R.raw.t)

    val u = MediaPlayer.create(mContext, R.raw.u)
    val v = MediaPlayer.create(mContext, R.raw.v)
    val w = MediaPlayer.create(mContext, R.raw.w)
    val x = MediaPlayer.create(mContext, R.raw.x)
    val y = MediaPlayer.create(mContext, R.raw.y)
    val z = MediaPlayer.create(mContext, R.raw.z)

    Column(
        modifier = Modifier.padding(10.dp)
    ) {

        Row(
            modifier = Modifier.weight(1f)
        ) {
            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { a.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "A",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { b.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "B",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }


            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { c.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "C",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }


            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { d.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "D",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.weight(1f)
        ) {
            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { e.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "E",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { f.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "F",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }


            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { g.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "G",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }


            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { h.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "H",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.weight(1f)
        ) {
            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { i.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "I",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { j.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "J",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }


            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { k.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "K",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }


            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { l.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "L",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }


        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.weight(1f)
        ) {
            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { m.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "M",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { n.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "N",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }


            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { o.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "O",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }


            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { p.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "P",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }


        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.weight(1f)
        ) {
            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { q.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "Q",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { r.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "R",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }


            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { s.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "S",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }


            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { t.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "T",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }


        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.weight(1f)
        ) {
            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { u.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "U",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { v.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "V",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }


            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { w.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "W",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }


            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { x.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "X",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }


        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.weight(1f)
        ) {
            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { y.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "Y",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

            Spacer(modifier = Modifier.width(10.dp))


            Card(
                shape = RoundedCornerShape(8.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
                colors = CardDefaults.cardColors(colorResource(id = R.color.white)),
                modifier = Modifier
                    .fillMaxWidth()
                    .fillMaxHeight()
                    .weight(1f)
                    .clickable { z.start() }
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .fillMaxHeight()
                ) {
                    Text(
                        text = "Z",
                        color = colorResource(id = R.color.black),
                        fontSize = 25.sp,
                        fontWeight = FontWeight.Black
                    )
                }
            }

        }

    }


}